package pl.edu.uwm.obiektowe.s162436;

public enum Producent {
    FORD,
    AUDI,
    BMW,
    SKODA;
}