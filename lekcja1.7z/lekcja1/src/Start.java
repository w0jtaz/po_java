public class Start {
    public static void main(String[] args){

        //zadanie1
        System.out.println(30+31+30);

        //zadanie2
        System.out.println(1+2+3+4+5+6+7+8+9+10);

        //zadanie3
        System.out.println(1*2*3*4*5*6*7*8*9*10);

        //zadanie4
        System.out.println(1000+(1000*0.06/12)*3);

        //zadanie6
        System.out.println(" "+"/"+"/"+"/"+"/"+"/");
        System.out.println("+"+'"'+'"'+'"'+'"'+'"'+"+");
        System.out.println("("+"|"+"o"+" "+"o"+"|"+")");
        System.out.println(" "+"|"+" "+"^"+" "+"|");
        System.out.println("|"+"‘"+"_"+"’"+"|");
        String printable = "Znaki specjalne \uFFE6";
        System.out.println(printable);

        //10 12
        //zadanie 10
        System.out.println("Film 1");
        System.out.println("Film 2");
        System.out.println("Film 3");


        //zadanie11
        System.out.println("Lata osa koło nosa\n" +
                "Lata mucha koło ucha\n" +
                "Lata bąk koło rąk\n" +
                "Lecą ważki koło paszki\n" +
                "Lata pszczoła koło czoła\n" +
                "Lata mucha koło brzucha\n" +
                "Lecą muszki koło nóżki\n" +
                "Biegną mrówki koło główki");


    }
}
