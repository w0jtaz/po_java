public class Start {
    public static void main(String[] args){

        //zadanie1
        System.out.println(30+31+30);

        //zadanie2
        System.out.println(1+2+3+4+5+6+7+8+9+10);

        //zadanie3
        System.out.println(1*2*3*4*5*6*7*8*9*10);

        //zadanie4
        System.out.println(1000+(1000*0.06/12)*3);

        //zadanie6
        System.out.println(" "+"/"+"/"+"/"+"/"+"/");
        System.out.println("+"+'"'+'"'+'"'+'"'+'"'+"+");
        System.out.println("("+"|"+"o"+" "+"o"+"|"+")");
        System.out.println(" "+"|"+" "+"^"+" "+"|");
        System.out.println("|"+"‘"+"_"+"’"+"|");

    }
}
